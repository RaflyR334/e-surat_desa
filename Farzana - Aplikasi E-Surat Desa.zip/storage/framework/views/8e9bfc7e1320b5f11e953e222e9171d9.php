<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.residentForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Downloads\Compressed\esuratdesa-main\resources\views/resident/create.blade.php ENDPATH**/ ?>