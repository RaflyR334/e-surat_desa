<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js', 'resources/js/sweetalert.js', 'resources/js/chart.js']); ?>
    <title>E-Surat Desa</title>
</head>

<body>
<?php /**PATH C:\Users\USER\Downloads\Compressed\esuratdesa-main\resources\views/layouts/header.blade.php ENDPATH**/ ?>